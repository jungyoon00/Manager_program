import time

def write_log(mypath: str, kind: str):
    savepath = mypath + "/docs/errors_log.txt"

    open_log = open(savepath, 'a')

    tm = time.localtime(time.time())
    now = time.strftime('%Y-%m-%d %I:%M:%S %p', tm)

    open_log.write(now[:len(now)-3], "|", kind)
    open_log.close()
