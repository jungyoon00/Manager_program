import re

def link_short(get: str, form="(http(s)?://)?(www[.])?(?P<source>.+)") -> str:
    get.replace("\n", "")
    get.replace(" ", "")
    link_form = re.match(form, get)
    processed = link_form.group("source")

    if len(processed) >= 35:
        processed = processed[:35] + "..."
    
    return processed

def text_short(get: str) -> str:
    processed = get.replace("\n", "")

    return processed

def text_to_variable(get: str, pre: str) -> str:
    ban_list_text = ["+", "-", "*", "/", "$", "@", "&", "%", ".", ":"]
    processed = get[:]

    for b in ban_list_text:
        processed = processed.replace(b, "")
    for n in range(0, 10):
        processed = processed.replace(str(n), "")
    
    if len(processed) >= 40:
        result = pre + str(processed[:40])
    else:
        result = pre + str(processed)

    return result

def link_secure(get: str):
    form = "((?P<security>http(s)?)://)?(?P<identity>www)?.+"
    link_form = re.match(form, get)
    security_part = link_form.group("security")

    if security_part == "https":
        security_lvl = "High"
        dialog = "This site is encrypted."
    elif security_part == "http":
        security_lvl = "Middle"
        dialog = "This site is not encrypted. (recommend to use 'https')"
    else:
        if link_form.group("identity"):
            security_lvl = "Low"
            dialog = "This site is unstable. (recommend to use 'https')"
        else:
            security_lvl = "Bad"
            dialog = "This site is not verified. (Warning!)"
    
    return security_lvl, dialog