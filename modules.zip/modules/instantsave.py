def save_temp(mypath: str, contents: str):
    savepath = mypath + "/file_tab/docs/temp_file_memory/temp_memory.txt"

    open_temp = open(savepath, 'r')
    in_temp = open_temp.readlines()

    if in_temp == "":
        index = 1
    else:
        index = len(in_temp) + 1
    
    open_temp.close()
    write_temp = open(savepath, 'a')
    write_temp.write(index, ":", contents)

def save_recently(mypath: str, index: int, contents):
    if index == 0:
        filename = "recently_labels.txt"
    elif index == 1:
        filename = "recently_links.txt"
    else:
        return None

    savepath = mypath + "/file_tab/docs/recently_log/" + filename

    read_recent = open(savepath, 'r')

    if read_recent.read():
        first = "\n"
    else:
        first = ""
    read_recent.close()

    open_recent = open(savepath, 'a')
    if type(contents) == list:
        for c in contents:
            open_recent.write(first + c)
            first = "\n"
    elif type(contents) == str:
        open_recent.write(first + contents)
    else:
        print("Error -Unexpected Type")
    open_recent.close()

    check_recent = open(savepath, 'r')
    check_list = check_recent.readlines()
    if len(check_list) > 5:
        check_recent.close()
        process = open(savepath, 'w')
        processed_list = check_list[-5:]
        process.writelines(processed_list)
        process.close()
    else:
        check_recent.close()